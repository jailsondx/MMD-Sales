import './Central.css'

function Central() {

    return (
      <div className="central">
        <h1>Bem Vindo</h1>
      </div>
    )
  }
  
  export default Central;
  