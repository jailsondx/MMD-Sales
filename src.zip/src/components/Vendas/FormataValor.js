// Função para formatar valores (substitui um caractere por outro)
export default function FormataValor(valor, char_troca, char_novo) {
    return valor.replace(char_troca, char_novo);
}
