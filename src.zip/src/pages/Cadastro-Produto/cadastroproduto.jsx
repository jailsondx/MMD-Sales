// pages/Cadastro.js
import React from 'react';
import FormCadastroProduto from '../../components/Form Produto/FormCadastroProduto';

function CadastroProduto() {
  return (
    <div>
      <FormCadastroProduto />
    </div>
  );
}

export default CadastroProduto;
