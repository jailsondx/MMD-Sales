// pages/Home.js
import React from 'react';
import Central from '../../components/Central/Central';

function Home() {
  return (
    <div>
      <Central />
    </div>
  );
}

export default Home;
