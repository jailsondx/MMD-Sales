// pages/Vendas.js
import React from 'react';
import TelaVendas from '../../components/Vendas/Vendas';

function Vendas() {
  return (
    <div>
      <TelaVendas />
    </div>
  );
}

export default Vendas;
