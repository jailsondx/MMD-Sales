// pages/Cadastro.js
import React from 'react';
import FormCadastroMercadoria from '../../components/Form Mercadoria/FormCadastroMercadoria';

function CadastroMercadoria() {
  return (
    <div>
      <FormCadastroMercadoria />
    </div>
  );
}

export default CadastroMercadoria;
